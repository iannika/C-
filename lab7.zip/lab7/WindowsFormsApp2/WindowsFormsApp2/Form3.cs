﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form3 : WindowsFormsApp2.Form1
    {
        public Form3()
        {
            InitializeComponent();
        }
    }
}
